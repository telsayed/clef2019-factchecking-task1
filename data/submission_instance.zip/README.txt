1. Team ID: The B Team
2. Team affiliation: University of A Night at the Opera
3. Contact email: me@uni_opera.edu
4. System specs
- 4.1 Core approach
	We used an LSTM  with 300 hundred layers, 2000 units per layer,
	and RelU optimisation. We trained the model with a batch of 20 
	for 1000 epochs.
- 4.3 Important/interesting/novel novel representations used (features, embeddings...)
	Primary: We used 3-d embeddings with 47 features that represent
	the contents [...]. 
	Contrastive 1: we used 5-d embeddings instead.
	Contrastive 2: we used an SVM regressor 
- 4.4 Important/interesting/novel tools used
	We used the neural networks implemented in kelp (http://www.kelp-ml.org/)

- 4.5 Significant data pre/post-processing
	After tokenisation and lemmatisation, we discarded nouns.

- 4.6 Other data used (outside of the provided)
	We used the debates from the 1876 US election.

5 References (if applicable)
	None applicable.