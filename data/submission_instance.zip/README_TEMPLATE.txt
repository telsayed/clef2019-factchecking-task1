1. Team ID: 
2. Team affiliation: 
3. Contact email: 
4. System specs
- 4.1 Core approach
- 4.3 Important/interesting/novel novel representations used (features, embeddings...)
- 4.4 Important/interesting/novel tools used
- 4.5 Significant data pre/post-processing
- 4.6 Other data used (outside of the provided)
5 References (if applicable)
